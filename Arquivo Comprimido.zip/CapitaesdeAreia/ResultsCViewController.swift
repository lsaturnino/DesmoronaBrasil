//
//  ResultsCViewController.swift
//  CapitaesdeAreia
//
//  Created by aluno on 14/05/22.
//

import UIKit

class ResultsCViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .systemBlue
    }
    

    

}
