//
//  MenuView.swift
//  CapitaesdeAreia
//
//  Created by aluno on 12/04/22.
//

import SwiftUI

struct MenuView: View {
    var body: some View {
        VStack{}
    }
}

struct MenuView_Previews: PreviewProvider {
    static var previews: some View {
        MenuView()
    }
}
